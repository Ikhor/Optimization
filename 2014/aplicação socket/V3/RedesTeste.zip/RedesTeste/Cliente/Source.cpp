#include <iostream>

using namespace std;


void troca (int *v, int i, int j) {
    int aux = v[i];
    v[i] = v[j];
    v[j] = aux;
}
 
int main () {
    
	int n;    
    while (cin >> n && n != 0) {

        int *vetor = new int[n];
        for (int i = 0; i < n; i++)
			cin >> vetor[i];
        
		int trocas = 0;
         
        int i = 0;
        while (i < n) {
            while (vetor[i] != i+1) {
                troca (vetor, i, vetor[i]-1);
                trocas = 1-trocas;
            }
            i++;
        }
         
        if (trocas == 0) 
			cout  << "Carlos\n";
		else
			cout << "Marcelo\n";
         
        delete vetor;
        
    }
}
