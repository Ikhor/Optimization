#include "Server.h"

void Server::InitServer(){

	ipServidor = "127.0.0.1";//Por Padr�o est� localhost
	TamanhoFilaEspera = 5;//Por padr�o 5 clientes podem e esperar

	// Winsock DLL
	WSADATA wsadata;
	if(WSAStartup(0x101,(LPWSADATA)&wsadata) != 0) {
		printf("Winsock Error\n");
		exit(1);                                         
	}
	
	//  server socket
	server_sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if(server_sockfd == SOCKET_ERROR) {
		printf("Socket Error\n");
		exit(1);
	}

	server_address.sin_family = AF_INET; // AF_INT(IPv4)
	server_address.sin_addr.s_addr = inet_addr(ipServidor);// IP
	server_address.sin_port = 9734; //Porta 
	server_len = sizeof(server_address);

	if(bind(server_sockfd, (struct sockaddr *)&server_address, server_len) < 0) {
		printf("Bind Error\n");
		exit(1);
	}

	if(listen(server_sockfd, TamanhoFilaEspera) < 0) {
		printf("Listen Error\n");
		exit(1);
	}

	while(true) {

		std::cout << "Waiting ...\n";
		client_len = sizeof(client_address);

		client_sockfd = accept(server_sockfd, (struct sockaddr *)&client_address, &client_len);
		
		if(client_sockfd == SOCKET_ERROR) {
			printf("Accept Error\n");
			exit(1);
		}
		
	
		Handle();//Handle Protocol
		
		closesocket(client_sockfd); // socket close client
	}
	
	closesocket(server_sockfd); // socket close server
}


void Server::Handle(){
	
	char out_buf[MAX_WIRE_SIZE], in_buf[MAX_WIRE_SIZE];

	memset(out_buf, 0, MAX_WIRE_SIZE);

	//Types 0 - Generator / 1 - Get Solution 2 - Set Solution
	int result = decode_Type(in_buf);
	if(result == 0)
		Generator();
	else if(result == 1)
		GetSolution();
	else if(result == 2){
		int resultDecodeData = decode_Data(in_buf);

	}

);

	
}



void Server::sendMsg(SOCKET sockfd,char* mensagemEnvia){

	//Envia Msg
	send(sockfd, mensagemEnvia, 1024, 0);
	
	delete [] mensagemEnvia;
}

char* Server::recvMsg(SOCKET sockfd){

	char mensagemRecebe[1024];
	//RecebeMsg
	recv(sockfd, mensagemRecebe, 1024, 0);
	
	return mensagemRecebe;
}