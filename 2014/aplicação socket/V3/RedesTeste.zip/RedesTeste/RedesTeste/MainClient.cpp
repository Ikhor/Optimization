#include "Client.h"

int main(){

	Client client;
	client.InitClient();

	client.Start();

}