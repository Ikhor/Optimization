#include "Server.h"

int main(){

	Server servidor;
	servidor.InitServer();

	servidor.Start();

}