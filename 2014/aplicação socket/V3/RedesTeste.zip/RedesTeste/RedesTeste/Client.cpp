#include "Client.h"
#include <list>

void Client::sendMsg(SOCKET sockfd,char* mensagemEnvia){

	//Envia Msg
	send(sockfd, mensagemEnvia, 1024, 0);
	
	delete [] mensagemEnvia;
}

char* Client::recvMsg(SOCKET sockfd){

	char mensagemRecebe[1024];
	//RecebeMsg
	recv(sockfd, mensagemRecebe, 1024, 0);
	
	return mensagemRecebe;
}

void Client::InitClient(){

	ipServidor = "127.0.0.1";//Por Padr�o est� localhost

	WSADATA wsadata;
	if(WSAStartup(0x101,(LPWSADATA)&wsadata) != 0) {
		printf("Winsock Error\n"); 
		exit(1);
	}
	
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = inet_addr(ipServidor);
	address.sin_port = 9734;
	len = sizeof(address);

	result = connect(sockfd, (struct sockaddr *)&address, len);  

	if(result == -1) {
		printf("Connect Error");
		exit(1);
	}

}
   
void Client::Start(){
  
	/*
	Protocolo:
	Envia mensagem dizendo que � um otimizador
	recebe fun��o obj + solucao inicial

	fecha conex�o

	otimiza

	abre conex�o
	posta solucao

	fecha conexao

	*/
	char *type = "Optimizer";
	sendMsg(sockfd,type);

	char *get = "Get";
	sendMsg(sockfd,get);

	char * Data = recvMsg(sockfd);	

	closesocket(sockfd);

	//Tratar Data e iniciar o otimizador
	
	Optimizer();

	InitClient();

	type = "Post";
	sendMsg(sockfd,type);

	Data = MountData();
	sendMsg(sockfd,Data);

	closesocket(sockfd);
}

void Client::Optimizer(){

}

char* Client::MountData(){
	
	string Data =  Ext.size()+ "|";
	for(auto it = Ext.begin(); it != Ext.end(); it++)
		Data += (*it) + "|";

	char *msg = new char[Data.length() + 1];
	strcpy(msg, Data.c_str());

	return msg;
}

//parei aki
//http://stackoverflow.com/questions/8438686/convert-char-to-string-c
//http://stackoverflow.com/questions/7352099/stdstring-to-char
void Client::DismountData(char *Data){
	
	string Data =  Ext.size()+ "|";
	for(auto it = Ext.begin(); it != Ext.end(); it++)
		Data += (*it) + "|";

	char *msg = new char[Data.length() + 1];
	strcpy(msg, Data.c_str());

	

}