#include "Server.h"
#include <stdio.h>
#include <string.h>

//Magic word
static const char *DELIMITER = "|";
static const char *O_MAGIC = "Optmizer";
static const char *G_MAGIC = "Get";
static const char *S_MAGIC = "Set";
static const char *D_MAGIC = "Digest";
static const char *GE_MAGIC = "Generator";
static const char *SO_MAGIC = "Solution";

int decode_Type(char *in_buf){
	char *token;
	token = strtok(in_buf, DELIMITER);

	if (token == NULL) 
		return -1;
	if (strcmp(token, O_MAGIC) == 0) {
		log(log_option, "ok.\n");
	}
	else if (strcmp(token, GE_MAGIC) == 0){
		log(log_option, "ok.\n");
		return 0;
	}else {
		log(log_option, "ERROR! magic word was NOT recognized. Exiting...\n");
		return -1;
	}
	log(log_option, "\t>>> extracting status phrase...");
	token = strtok(NULL, DELIMITER);
	if (token == NULL) 
		return -1;
	if (strcmp(token, G_MAGIC) == 0) {
		log(log_option, "phrase is 'get'.\n");		
		return 1;
	}else if (strcmp(token, S_MAGIC) == 0){
		log(log_option, "phrase is 'set'.\n");	
		return 2;
	}else {
		log(log_option, "ERROR! phrase is NOT 'ok'. Exiting...\n");
		return -1;
	}
}
 
int encode_Data(char *out_buf){
	
	char *ptr = out_buf;
	long size = (long) MAX_WIRE_SIZE;
	log(log_option, "\t>>> inserting magic word...");
	int rv = sprintf(ptr, "%s", SO_MAGIC);
	log(log_option, "ok.\n");

	ptr += rv;
	size -= rv;
	log(log_option, "\t>>> inserting field delimiter...");
	rv = sprintf(ptr, "%s", DELIMITER);
	log(log_option, "ok.\n");
	ptr += rv;
	size -= rv;
	

	//Pecorrer a solu��o e coloca-la na string
	struct option *options = qst->options;
	struct option *aux = options;
	while (aux != NULL) {
		log(log_option, "\t>>> inserting option...");
		rv = snprintf(ptr, size, "%s", aux->opt);
		log(log_option, "ok.\n");
		ptr += rv;
		size -= rv;
		aux = aux->next;
		if (aux != NULL) {
			log(log_option, "\t>>> inserting field delimiter...");
			rv = snprintf(ptr, size, "%s", DELIMITER);
			log(log_option, "ok.\n");
			ptr += rv;
			size -= rv;
		}
	}

}

void encode_setup(int qst_number, int opt_number, char *out_buf) {
  char *ptr = out_buf;
  int size = MAX_WIRE_SIZE;
  quiz_log(log_option, "\t>>> inserting magic word...");
  int rv = snprintf (ptr, 100, "%s", S_MAGIC);
  quiz_log(log_option, "ok.\n");
  ptr += rv;
  size -= rv;
  quiz_log(log_option, "\t>>> inserting field delimiter...");
  rv = snprintf(ptr, size, "%s", DELIMITER);
  quiz_log(log_option, "ok.\n");
  ptr += rv;
  size -= rv;
  quiz_log(log_option, "\t>>> inserting number of questions...");
  rv = snprintf(ptr, size, "%d", qst_number);
  quiz_log(log_option, "ok.\n");
  ptr += rv;
  size -= rv;
  quiz_log(log_option, "\t>>> inserting field delimiter...");
  rv = snprintf(ptr, size, "%s", DELIMITER);
  quiz_log(log_option, "ok.\n");
  ptr += rv;
  size -= rv;
  quiz_log(log_option, "\t>>> inserting number of options...");
  rv = snprintf(ptr, size, "%d", opt_number);
  quiz_log(log_option, "ok.\n");
}

int decode_setupAck(char *in_buf) {
  char *token;
  token = strtok(in_buf, DELIMITER);
  quiz_log(log_option, "\t>>> extracting magic word...");
  if (token == NULL) 
    return -1;
  if (strcmp(token, SA_MAGIC) == 0) {
    quiz_log(log_option, "ok.\n");
  } else {
    quiz_log(log_option, "ERROR! magic word was NOT recognized. Exiting...\n");
    return -1;
  }
  quiz_log(log_option, "\t>>> extracting status phrase...");
  token = strtok(NULL, DELIMITER);
  if (token == NULL) 
    return -1;
  if (strcmp(token, OK_PHRASE) == 0) {
    quiz_log(log_option, "phrase is 'ok'.\n");
    return 0;
  } else {
    quiz_log(log_option, "ERROR! phrase is NOT 'ok'. Exiting...\n");
    return -1;
  }
}

void encode_question(struct question *qst, char *out_buf) {
  char *ptr = out_buf;
  long size = (long) MAX_WIRE_SIZE;
  quiz_log(log_option, "\t>>> inserting magic word...");
  int rv = snprintf(ptr, size, "%s", Q_MAGIC);
  quiz_log(log_option, "ok.\n");
  ptr += rv;
  size -= rv;
  quiz_log(log_option, "\t>>> inserting field delimiter...");
  rv = snprintf(ptr, size, "%s", DELIMITER);
  quiz_log(log_option, "ok.\n");
  ptr += rv;
  size -= rv;
  quiz_log(log_option, "\t>>> inserting question statement...");
  rv = snprintf(ptr, size, "%s", qst->stmt);
  quiz_log(log_option, "ok.\n");
  ptr += rv;
  size -= rv;
  quiz_log(log_option, "\t>>> inserting field delimiter...");
  rv = snprintf(ptr, size, "%s", DELIMITER);
  quiz_log(log_option, "ok.\n");
  ptr += rv;
  size -= rv;
  struct option *options = qst->options;
  struct option *aux = options;
  while (aux != NULL) {
    quiz_log(log_option, "\t>>> inserting option...");
    rv = snprintf(ptr, size, "%s", aux->opt);
    quiz_log(log_option, "ok.\n");
    ptr += rv;
    size -= rv;
    aux = aux->next;
    if (aux != NULL) {
      quiz_log(log_option, "\t>>> inserting field delimiter...");
      rv = snprintf(ptr, size, "%s", DELIMITER);
      quiz_log(log_option, "ok.\n");
      ptr += rv;
      size -= rv;
    }
  }
}

char decode_answer(char *in_buf) {
  char *token;
  token = strtok(in_buf, DELIMITER);
  quiz_log(log_option, "\t>>> extracting magic word...");
  if (token == NULL) 
    return '?';
  if (strcmp(token, A_MAGIC) == 0) {
    quiz_log(log_option, "ok, magic word was recognized.\n");
  } else {
    quiz_log(log_option, "ERROR! magic word was NOT recognized. Exiting...\n");
    return '?';
  }
  quiz_log(log_option, "\t>>> extracting answer...");
  token = strtok(NULL, DELIMITER);
  quiz_log(log_option, "ok.\n");
  return token[0];
}

void encode_digest(int matches, struct question *qst, char *out_buf) {
  char *ptr = out_buf;
  long size = (long) MAX_WIRE_SIZE;
  quiz_log(log_option, "\t>>> inserting magic word...");
  int rv = snprintf(ptr, size, "%s", D_MAGIC);
  quiz_log(log_option, "ok.\n");
  ptr += rv;
  size -= rv;
  quiz_log(log_option, "\t>>> inserting field delimiter...");
  rv = snprintf(ptr, size, "%s", DELIMITER);
  quiz_log(log_option, "ok.\n");
  ptr += rv;
  size -= rv;
  quiz_log(log_option, "\t>>> inserting user's matches...");
  rv = snprintf(ptr, size, "%d", matches);
  quiz_log(log_option, "ok.\n");
  ptr += rv;
  size -= rv;
  quiz_log(log_option, "\t>>> inserting field delimiter...");
  rv = snprintf(ptr, size, "%s", DELIMITER);
  quiz_log(log_option, "ok.\n");
  ptr += rv;
  size -= rv;
  struct question *aux = qst;
  while (aux != NULL) {
    quiz_log(log_option, "\t>>> inserting correct answer...");
    rv = snprintf(ptr, size, "%c", aux->correct);
    quiz_log(log_option, "ok.\n");
    ptr += rv;
    size -= rv;
    aux = aux->next;
    if (aux != NULL) {
      quiz_log(log_option, "\t>>> inserting field delimiter...");
      rv = snprintf(ptr, size, "%s", DELIMITER);
      quiz_log(log_option, "ok.\n");
      ptr += rv;
      size -= rv;
    }
  }
}

void log(int log_option, char *str) {
  if (log_option == 1) 
    printf("%s", str);
}


