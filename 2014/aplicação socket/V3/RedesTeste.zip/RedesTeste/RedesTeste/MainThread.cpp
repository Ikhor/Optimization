#include "Server.h"
#include "Client.h"

int main(){

	/*
	Server servidor;
	servidor.InitServer();

	servidor.Start();
	*/
	
	Client client;
	client.InitClient();

	client.Start();
	

}