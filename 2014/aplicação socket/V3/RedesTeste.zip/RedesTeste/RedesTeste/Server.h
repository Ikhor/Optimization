#include<winsock2.h>
#include<iostream>
#include<stdio.h>


#define MAX_WIRE_SIZE 1000
int log_option = 1;

using namespace std;

class Server{

private:
	SOCKET server_sockfd;
	SOCKET client_sockfd;
	int server_len;
	int client_len;
	struct sockaddr_in server_address;
	struct sockaddr_in client_address;
	char *ipServidor; //Deixar por padr�o localhost. O valor est� sendo colocado no metodo InitServer
	int TamanhoFilaEspera;//5 clientes poder�o esperar na fila

	void Generator();
	void GetSolution();
	void SetSolution();

public:

	void InitServer();
	void Handle();

};
